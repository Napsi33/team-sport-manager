<?php
session_start();
include 'auth.php';
?>

<?php include "header.php"; ?>

<h2>
    Welcome
</h2>
<p>This is a sport team manager webpage, where you can freely keep track of the results of all the sports you follow and love!</p>
<?php include "footer.php"; ?>
