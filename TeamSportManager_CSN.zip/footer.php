        </div>
        <div class="footer-wrapper">
            <p>Napsugár Csanádi, 2024</p>
        </div>
    </body>
</html>